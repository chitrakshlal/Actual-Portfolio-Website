export const navItems = [
  { label: "Home", path: "/" },
  { label: "About", path: "/about-me" },
  { label: "Projects", path: "/aeronautical-projects" },
  { label: "Skills", path: "/skills-experiences" },
  { label: "Certifications", path: "/certifications" },
];

export const profile = {
  name: "Chitraksh Lal Ajit Kumar",
  label: "Aspiring Licensed Aircraft Engineer",
  email: "chitrakshlal1507@gmail.com",
  linkedin: "https://linkedin.com/in/chitrakshlalajitkumar/?skipRedirect=true",
  whatsapp: "https://api.whatsapp.com/send?phone=6587141505",
  portrait: "/assets/home/whatsapp-image-2026-05-28-at-1-41-33-pm-high-g8hdtx.jpg",
  portraitLarge: "/assets/about/portrait-full.jpg",
};

export const homeImages = {
  hero: "/assets/home/whatsapp-image-2026-05-12-at-7-03-19-pm-high-04yruo.jpg",
  secondary: "/assets/home/whatsapp-image-2026-01-09-at-12-32-06-pm-high-fd7pck.jpg",
};

export const heroStats = [
  { value: "Aeronautical", label: "Diploma pathway" },
  { value: "CAD + Design", label: "Project focus" },
  { value: "MRO", label: "Industry exposure" },
];

export const homeCards = [
  {
    title: "Academic Based Projects",
    description: "Explore projects that I had taken on!",
    button: "View projects",
    path: "/aeronautical-projects",
    image: "/assets/home/whatsapp-image-2026-05-12-at-7-03-19-pm-high-04yruo.jpg",
  },
  {
    title: "Skills & Experiences",
    description: "Explore my technical and soft skills and how i obtained them.",
    button: "View projects",
    path: "/skills-experiences",
    image: "/assets/home/whatsapp-image-2026-01-09-at-12-32-06-pm-high-fd7pck.jpg",
  },
];

export const aboutParagraphs = [
  "Hi! My name is Chitraksh Lal Ajit Kumar, and I am currently pursuing a Diploma in Aeronautical Engineering. As an aspiring Licensed Aircraft Engineer, I have developed a strong passion for aviation from a young age and look forward to building a career working closely with aircraft and the aerospace industry.",
  "Beyond aerospace engineering, I am also passionate about long distance running, which has helped me develop discipline, consistency, and mental resilience. Through running, I have learned the importance of perseverance, goal setting, and pushing beyond personal limits, qualities that I believe are equally valuable within both engineering and everyday life.",
];

export const featuredAreas = [
  {
    title: "Aeronautical Projects",
    eyebrow: "Design, fabrication, evaluation",
    description: "CAD modelling, engineering drafting, launcher fabrication, prototyping, and analysis work from academic project builds.",
    path: "/aeronautical-projects",
    image: "/assets/aeronautical/exploded-view-high-slrpny.png",
  },
  {
    title: "Skills & Experiences",
    eyebrow: "Technical and professional growth",
    description: "A focused view of CAD, drafting, teamwork, MRO exposure, stakeholder engagement, and communication work.",
    path: "/skills-experiences",
    image: "/assets/skills/mro-exposure.jpg",
  },
  {
    title: "Certifications",
    eyebrow: "Training and recognition",
    description: "A concise archive of aviation-related learning, academic achievements, and technical exposure.",
    path: "/certifications",
    image: "/assets/certifications/666827c920e71571abfd6ee3_ad_4nxessyuaiienrde0u5zae9iuypzacbzwgqpcgyirpfb-r6iz6m-et5usym3hl1ctxc9qftuqauj41ljyaydz9x54b6qzka-9i-30dt8toja7d3dneyyvwhptcqb8a2dnqzqbvn0zxd2lvk.jpg",
  },
];

export const project = {
  title: "Launcher Design and Fabrication",
  subtitle: "A functional aircraft launcher developed through CAD modelling, drafting, prototyping, manufacturing, and physical evaluation.",
  details: [
    "Designed and fabricated a functional aircraft launcher using a combination of 3D modelling, engineering drafting, and manufacturing processes. The project involved developing 3D CAD models and assemblies using CATIA V5 and Autodesk Inventor, while applying design for manufacturing principles throughout the development process.",
    "2D technical drawings and dimensional layouts were generated to support drafting documentation and configuration updates. The project also incorporated 3D printing for rapid prototyping and physical analysis and evaluation, improving my understanding of tolerancing, manufacturability, and assembly with respect to the catapult.",
    "Engineering considerations such as structural support, component alignment, weight distribution, and part integration were evaluated through multiple design iterations to improve functionality and reliability.",
  ],
  highlights: ["CATIA V5", "Autodesk Inventor", "3D printing", "2D drafting", "Assembly design", "Physical testing"],
};

export const projectCases = [
  {
    title: "Launcher Design and Fabrication",
    images: [
      "/assets/aeronautical/exploded-view-high-slrpny.png",
      "/assets/aeronautical/catapualt-high.png",
      "/assets/aeronautical/drafting-high-qr3720.png",
      "/assets/aeronautical/whatsapp-image-2026-05-10-at-1-47-54-pm-high-ki8uqf.jpg",
    ],
    paragraphs: [
      "Designed and developed a launcher prototype using CATIA for 3D modelling and design visualization. Utilized multiple CATIA workbenches including Part Design, Mechanical Design, Sheet Metal Design, Assembly Design, and Drafting.",
      "I ensured sketches and assemblies were fully constrained for dimensional accuracy and stability. The project also involved producing 2D engineering drawings to communicate overall dimensions and design intent.",
      "Engineering constraints such as riveting points, bending limitations, structural stability, and size restrictions were considered throughout the design process while optimizing launch performance and consistency. Multiple testing iterations were conducted to refine the design and improve overall functionality.",
    ],
  },
  {
    title: "Glider Design & Fabrication",
    images: [
      "/assets/aeronautical/whatsapp-image-2026-05-10-at-1-47-54-pm-1-standard.jpg",
      "/assets/aeronautical/profile-analysis-high.png",
      "/assets/aeronautical/whatsapp-image-2026-05-28-at-12-27-13-pm-high.jpg",
      "/assets/aeronautical/whatsapp-image-2026-05-28-at-12-27-52-pm-high-fxjo6n.jpg",
      "/assets/aeronautical/whatsapp-image-2026-05-28-at-12-27-39-pm-high.jpg",
      "/assets/aeronautical/whatsapp-image-2026-05-28-at-12-27-23-pm-high-puxvm4.jpg",
    ],
    paragraphs: [
      "Developed a glider prototype using CATIA Mechanical Design workbenches, including Part Design, Assembly Design, and Drafting.",
      "I used the drafting feature for aerodynamic modelling of the aero foil. The project involved designing and refining an aero foil profile for the wings to improve lift performance and flight stability. Surface and skin modelling applications were utilized to create smooth aerodynamic wing geometries and optimize overall airflow characteristics.",
      "Engineering considerations such as structural strength, weight distribution, wing alignment, and dimensional constraints were incorporated throughout the design process. Fully constrained sketches and assemblies were maintained to ensure modelling accuracy and design consistency. Multiple design iterations and flight tests were conducted to evaluate glide performance and refine the final configuration.",
    ],
  },
  {
    title: "Catapult Seat Concept",
    images: [
      "/assets/aeronautical/whatsapp-image-2026-05-10-at-2-18-29-pm-standard.jpg",
      "/assets/aeronautical/photo_2026-05-10_14-24-02-high-3wr45x.jpg",
      "/assets/aeronautical/whatsapp-image-2026-05-10-at-2-18-29-pm-1-high-e9opoe.jpg",
      "/assets/aeronautical/whatsapp-image-2026-05-10-at-2-18-29-pm-2-high-lart4b.jpg",
    ],
    paragraphs: [
      "Designed and developed a catapult seat assembly using Autodesk Inventor for 3D CAD modelling, assembly integration, and engineering visualization. The project involved creating detailed components and fully constrained assemblies while applying design for manufacturing principles throughout the development process.",
      "2D technical drawings and dimensional layouts were generated to support drafting documentation and configuration updates. The project also incorporated 3D printing for rapid prototyping and physical analysis and evaluation, improving my understanding of tolerancing, manufacturability, and assembly with respect to the catapult.",
      "Engineering considerations such as structural support, component alignment, weight distribution, and part integration were evaluated through multiple design iterations to improve functionality and reliability.",
    ],
  },
];

export const projectGallery = [
  { src: "/assets/aeronautical/exploded-view-high-slrpny.png", title: "Exploded Assembly", label: "Component relationship and assembly sequence" },
  { src: "/assets/aeronautical/catapualt-high.png", title: "Launcher Build", label: "Fabricated mechanism and final configuration" },
  { src: "/assets/aeronautical/drafting-high-qr3720.png", title: "Technical Drafting", label: "Dimensional layout and drawing documentation" },
  { src: "/assets/aeronautical/profile-analysis-high.png", title: "Profile Analysis", label: "Evaluation of aerodynamic and mechanical considerations" },
  { src: "/assets/aeronautical/whatsapp-image-2026-05-10-at-1-47-54-pm-high-ki8uqf.jpg", title: "Prototype Review", label: "Physical design checks during iteration" },
  { src: "/assets/aeronautical/whatsapp-image-2026-05-28-at-12-27-52-pm-high-fxjo6n.jpg", title: "Project Documentation", label: "Visual record of testing and assembly work" },
  { src: "/assets/aeronautical/photo_2026-05-10_14-24-02-high-3wr45x.jpg", title: "Testing Setup", label: "Hands-on validation and adjustment" },
  { src: "/assets/aeronautical/whatsapp-image-2026-05-10-at-2-18-29-pm-1-high-e9opoe.jpg", title: "Build Detail", label: "Part integration and mechanical alignment" },
];

export const softSkills = [
  "Communication Skills",
  "Presentation Skills",
  "Teamwork & Collaboration",
  "Problem-Solving",
  "Critical & Design Thinking",
  "Adaptability",
  "Time Management",
  "Attention to Detail",
  "Perseverance & Resilience",
  "Analytical Thinking",
  "Mental Endurance",
  "Commitment",
  "Long Term Goal Discipline",
];

export const technicalSkills = [
  "CATIA V5",
  "Autodesk Inventor",
  "3D CAD Modelling",
  "2D Engineering Drafting",
  "Assembly Design",
  "Mechanical Design Workbenches",
  "Engineering Drawing Interpretation (Basic)",
  "Microsoft Office",
  "3D Printing (Basic)",
  "Composite Repair Fundamentals (Hand & Wet Layup) (Resin Infusion)",
  "Technical Documentation",
  "Soldering",
  "Turning/Milling (Basic)",
];

export const experiences = [
  {
    title: "MRO Exposure",
    image: "/assets/skills/mro-exposure.jpg",
    description: "I had the opportunity to visit the Singapore Airlines hangars and gain valuable exposure to the real world Maintenance, Repair and Overhaul industry through my deepening elective tracks. It was an eye opening experience to step into a professional aviation environment and observe how aircraft maintenance operations are carried out with precision, discipline, and strong safety practices.",
  },
  {
    title: "Fundraising",
    image: "/assets/skills/fundraising.jpg",
    description: "Together with the team, we engaged with members of the public and various stakeholders across the district to raise awareness and encourage donations for the cause. Through these interactions, I developed stronger communication and interpersonal skills by learning how to confidently engage with individuals from different backgrounds and explain the purpose of the initiative in a clear and meaningful manner.",
  },
  {
    title: "SIP Project Presentation",
    image: "/assets/skills/sip-project-presentation.jpg",
    description: "I had the opportunity to support the Singapore Polytechnic Innovation & Implementation Showcase, where I represented both the SIP Sustainable Innovation Project and Singapore Polytechnic as part of a booth engagement team.",
  },
];

export const certifications = [
  {
    title: "Certificate Of Completion",
    subtitle: "Gas Turbine Operation & Maintenance",
    image: "/assets/certifications/666827c920e71571abfd6ee3_ad_4nxessyuaiienrde0u5zae9iuypzacbzwgqpcgyirpfb-r6iz6m-et5usym3hl1ctxc9qftuqauj41ljyaydz9x54b6qzka-9i-30dt8toja7d3dneyyvwhptcqb8a2dnqzqbvn0zxd2lvk.jpg",
  },
  {
    title: "Certificate of Attendance",
    subtitle: "Aircraft Ground Handling & Practices",
    image: "/assets/certifications/bff86f_7366c25b5a8447948d0226d42fa53365-mv2-high.jpg",
  },
  {
    title: "Certificate of Academic Excellence",
    subtitle: "Academic recognition",
    image: "/assets/certifications/bff86f_7366c25b5a8447948d0226d42fa53365-mv2-high.jpg",
  },
];

export const pageTitles = {
  "/": "Chitraksh's Portfolio",
  "/about-me": "About | Chitraksh's Portfolio",
  "/aeronautical-projects": "Projects | Chitraksh's Portfolio",
  "/skills-experiences": "Skills | Chitraksh's Portfolio",
  "/certifications": "Certifications | Chitraksh's Portfolio",
};
