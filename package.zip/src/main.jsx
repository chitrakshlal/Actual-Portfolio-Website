import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { html } from "./lib/html.js";
import { startMotion, scrollToTop, stopMotion } from "./lib/animations.js";
import { Header } from "./components/Header.jsx";
import { Footer } from "./components/Footer.jsx";
import { pageTitles } from "./data/portfolio.js";
import { AboutPage, CertificationsPage, HomePage, ProjectsPage, SkillsPage } from "./pages/PortfolioPages.jsx";

const routes = new Set(Object.keys(pageTitles));
const pageComponents = {
  "/": HomePage,
  "/about-me": AboutPage,
  "/aeronautical-projects": ProjectsPage,
  "/skills-experiences": SkillsPage,
  "/certifications": CertificationsPage,
};

function normalizePath(pathname) {
  const path = pathname.replace(/\/$/, "") || "/";
  return routes.has(path) ? path : "/";
}

function App() {
  const [path, setPath] = useState(() => normalizePath(window.location.pathname));
  const CurrentPage = useMemo(() => pageComponents[path] || HomePage, [path]);

  useEffect(() => {
    document.title = pageTitles[path] || pageTitles["/"];
  }, [path]);

  useEffect(() => {
    const cleanup = startMotion();
    return cleanup;
  }, [path]);

  useEffect(() => () => stopMotion(), []);

  useEffect(() => {
    const handlePopState = () => setPath(normalizePath(window.location.pathname));
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  function navigate(nextPath) {
    const normalized = normalizePath(nextPath);
    if (normalized === path) return;
    window.history.pushState({}, "", normalized);
    setPath(normalized);
    scrollToTop();
  }

  function handleContentClick(event) {
    const anchor = event.target.closest?.("a[href]");
    if (!anchor) return;

    const url = new URL(anchor.href, window.location.origin);
    if (url.origin !== window.location.origin || !routes.has(normalizePath(url.pathname))) return;

    event.preventDefault();
    navigate(url.pathname);
  }

  return html`
    <a href="#main-content" className="skip-link">Skip to main content</a>
    <div className="site-shell" onClick=${handleContentClick}>
      <${Header} activePath=${path} onNavigate=${navigate} />
      <${CurrentPage} onNavigate=${navigate} />
      <${Footer} onNavigate=${navigate} />
    </div>
  `;
}

createRoot(document.getElementById("root")).render(React.createElement(App));
